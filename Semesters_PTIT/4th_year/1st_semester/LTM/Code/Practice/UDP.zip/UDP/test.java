package Ref;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

public class test {
    /* 802 */
    static String getMissingNumbers(String receive) {
        receive = receive.replace(" ", "");
        String[] data = receive.split(";");
        String[] arr = data[1].split(",");

        ArrayList<Integer> arr1 = new ArrayList<>();
        for (String s : arr) {
            arr1.add(Integer.parseInt(s));
        }
        String res = data[0] + ";";

        for (int i = 1; i <= arr1.get(0); i++) {
            if (!arr1.contains(i)) {
                res += i + ",";
            }
        }

        return res.substring(0, res.length() - 1);
    }

    /* 931 */
    static String getMaxMin(String receive) {
        receive = receive.replace(" ", "");
        String[] data = receive.split(";");
        String res = data[0] + ";";

        String[] arr = data[1].split(",");
        TreeSet<Integer> set = new TreeSet<>();
        for (String s : arr) {
            set.add(Integer.parseInt(s));
        }
        System.out.println("Set: " + set);

        // ArrayList<Integer> list = new ArrayList<>();
        // list.addAll(set);
        // System.out.println("List: " + list);

        // res += list.get(list.size() - 1) + ";" + list.get(0);
        res += set.last() + ";" + set.first();

        // ArrayList<Integer> list = new ArrayList<>();
        // for (String s : arr) {
        // list.add(Integer.parseInt(s));
        // }
        // Collections.sort(list, new Comparator<Integer>() {
        // @Override
        // public int compare(Integer o1, Integer o2) {
        // return o1 < o2 ? -1 : 1;
        // }
        // });
        // System.out.println("List: " + list);
        // res += list.get(list.size() - 1) + ";" + list.get(0);

        return res;
    }

    /* 932 */
    static String normalize(String receive) {
        receive = receive.replace(" ", "");
        String[] data = receive.split(";");
        String res = data[0] + ";";

        String s = data[1];
        res += s.substring(0, 1).toUpperCase()
                + s.substring(1).toLowerCase();
        return res;
    }

    /* 936 */
    static String removeChar(String receive) {
        receive = receive.replace(" ", "");
        String[] data = receive.split(";");
        String res = data[0] + ";";

        String s1 = data[1];
        String s2 = data[2];
        // for (String c : s1.split("")) {
        // if (!s2.contains(c)) {
        // res += c;
        // }
        // }
        for (String c : s2.split("")) {
            s1 = s1.replace(c, "");
        }
        res = s1;

        return res;
    }

    /* 934 */
    static String decodeCaesar(String receive) {
        receive = receive.replace(" ", "");
        String[] data = receive.split(";");
        String res = data[0] + ";";

        String strEncode = data[1];
        String s = data[2];

        int offset = Integer.parseInt(s);
        char[] charArray = strEncode.toCharArray();
        for (char c : charArray) {
            if (Character.isUpperCase(c)) {
                res += ((char) ('A' + (c - 'A' + offset) % 26));
            } else {
                res += ((char) ('a' + (c - 'a' + offset) % 26));
            }
        }
        return res;
    }

     /* 935 */
    static String regex(String receive) {
        receive = receive.replace(" ", "");
        String[] data = receive.split(";");

        String res = data[0] + ";";
        String str = data[1];

        String regex = "[^a-zA-Z]";
        str = str.replaceAll(regex, "");

        String[] arr = str.split("");
        LinkedHashSet<String> set = new LinkedHashSet<>();
        for (String s : arr) {
            set.add(s);
        }
        Iterator<String> iterator = set.iterator();
        while (iterator.hasNext()) {
            res += iterator.next();
        }

        return res;
    }

    public static void main(String[] args) throws IOException {
        // String msv = ";B20DCCN075;802";
        // InetAddress IPAddress = InetAddress.getByName("203.162.10.109");
        // int port = 2207;

        // DatagramSocket client = new DatagramSocket();

        // client.send(new DatagramPacket(msv.getBytes(), msv.length(), IPAddress,
        // port));

        // byte[] buff = new byte[1024];
        // DatagramPacket dp = new DatagramPacket(buff, buff.length);
        // client.receive(dp);
        // String receive = new String(dp.getData());

        /* 802 */
        // String receive = "requestId;10,2,3,5,6,5";
        // String res = getMissingNumbers(receive);

        /* 931 */
        // String receive = "requestId; 10, 2, 3, 5, 6, 5";
        // String res = getMaxMin(receive);

        /* 932 */
        // String receive = "requestId;aBFOANTGSTHJNSNFLWETK";
        // String res = normalize(receive);

        /* 934 */
        // String receive = "requestId;abcdefghijkLMNOPQRSTUVWYZ;7";
        // String res = decodeCaesar(receive);
        // String receive = "requestId;KHOOR;3";
        // String res = decodeCaesar(receive);

        /* 935 */
        // String receive = "requestId;2uy35098hgajg34t59nagKGO34J09HEN;[,530&$9je_]";
        // String res = regex(receive);

        /* 936 */
        String receive = "requestId;abcdefghiklmno;defghikl";
        String res = removeChar(receive);

        System.out.println(res);

        // client.send(new DatagramPacket(res.getBytes(), res.length(), IPAddress,
        // port));
        // client.close();
    }
}
