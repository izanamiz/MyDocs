/*
Một chương trình server hỗ trợ kết nối qua giao thức TCP tại cổng 806 (hỗ trợ thời gian giao tiếp tối đa cho mỗi yêu cầu là 5s). 
Yêu cầu xây dựng chương trình client thực hiện kết nối tới server trên sử dụng luồng byte dữ liệu (InputStream/OutputStream) để trao đổi thông tin theo thứ tự: 
a.	Gửi mã sinh viên và mã câu hỏi theo định dạng "studentCode;qCode". Ví dụ: "B16DCCN999;700"
b.	Nhận dữ liệu từ server là một chuỗi gồm hai giá trị nguyên được phân tách với nhau bằng  "|"
Ex: 2|5|9|11
c.	Thực hiện tìm giá trị tổng của các số nguyên trong chuỗi và gửi lên server
Ex: 27
d.	Đóng kết nối và kết thúc 
*/
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;

public class Bai2 {

    public static void main(String[] args) throws IOException {
        // Kết nối tới server
        Socket socket = new Socket("10.21.135.64", 806);

        // Tạo luồng vào và ra
        InputStream inputStream = socket.getInputStream();
        OutputStream outputStream = socket.getOutputStream();

        // Gửi chuỗi mã sinh viên và mã câu hỏi
        String studentCode = "B20DCCN535;700";
        outputStream.write(studentCode.getBytes());

        // Đọc dữ liệu từ server
        byte[] buffer = new byte[1024];
        int bytesRead = inputStream.read(buffer);
        String dataFromServer = new String(buffer, 0, bytesRead);

        // Tách dữ liệu thành các số nguyên
        String[] numbers = dataFromServer.split("\\|");
        int sum = 0;
        for (String number : numbers) {
            sum += Integer.parseInt(number);
        }

        // Gửi tổng giá trị lên server
        String result = sum + "\n";
        outputStream.write(result.getBytes());

        // Đóng kết nối
        socket.close();
    }
}
