import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Collections;

public class Main {
	public static void main(String[] args) throws UnknownHostException, IOException {
		Socket client = new Socket(InetAddress.getByName("10.20.85.177"),808);
		System.out.println(client);
		
		
		BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(client.getOutputStream()));
		BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(client.getInputStream()));
		
		
		bufferedWriter.write("B20DCCN075;600\n");
		bufferedWriter.flush();
				
		String[] domains = bufferedReader.readLine().split(", ");
		System.out.println(domains);
		ArrayList<String> list = new ArrayList<>();
		for(int i=0;i<domains.length;i++) {
			String tmp = domains[i];
			if(tmp.substring(tmp.length()-4).equals(".edu")) list.add(tmp);
		}
		
		String res = "";
		for(int i=0;i<list.size()-1;i++) {
			res = res + list.get(i) + ", ";
		}
		res+=list.get(list.size()-1);
		System.out.println(res);
		bufferedWriter.write(res);
		bufferedWriter.flush();
		bufferedWriter.close();

	}
}