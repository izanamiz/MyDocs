import java.io.*;
import java.net.Socket;

public class Main {
    public static void main(String[] args) {
        String serverAddress = "10.21.96.15";
        int serverPort = 807;
        String studentCode = "B20DCCN075";
        int qCode = 800;

        try {
            // Kết nối tới máy chủ qua cổng 807
            Socket socket = new Socket(serverAddress, serverPort);

            // Lấy đối tượng DataOutputStream để gửi dữ liệu tới máy chủ
            DataOutputStream dataOut = new DataOutputStream(socket.getOutputStream());

            // Gửi thông tin sinh viên và mã câu hỏi tới máy chủ
            String request = studentCode + ";" + qCode;
            dataOut.writeUTF(request);

            // Lấy đối tượng DataInputStream để nhận dữ liệu từ máy chủ
            DataInputStream dataIn = new DataInputStream(socket.getInputStream());

            // Nhận lần lượt hai số nguyên a và b từ server
            int a = dataIn.readInt();
            int b = dataIn.readInt();

            // Thực hiện tính toán tổng và gửi lên server
            int sum = a + b;
            dataOut.writeInt(sum);

            // Thực hiện tính toán tích và gửi lên server
            int product = a * b;
            dataOut.writeInt(product);

            // Đóng kết nối
            socket.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
