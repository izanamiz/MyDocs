import java.io.*;
import java.net.Socket;

public class Client {
    public static void main(String[] args) {
        String serverAddress = "10.20.85.177";
        int serverPort = 806;
        String studentCode = "B20DCCN075";
        int qCode = 700;

        try {
            // Kết nối tới máy chủ qua cổng 806
            Socket socket = new Socket(serverAddress, serverPort);

            // Lấy đối tượng OutputStream để gửi dữ liệu tới máy chủ
            OutputStream outputStream = socket.getOutputStream();
            PrintWriter out = new PrintWriter(outputStream, true);

            // Gửi thông tin sinh viên và mã câu hỏi tới máy chủ
            String request = studentCode + ";" + qCode;
            out.println(request);

            // Lấy đối tượng InputStream để nhận dữ liệu từ máy chủ
            InputStream inputStream = socket.getInputStream();
            BufferedReader in = new BufferedReader(new InputStreamReader(inputStream));

            // Nhận dữ liệu từ máy chủ
            String dataFromServer = in.readLine();
            System.out.println("Response: " + dataFromServer);

            // Tách chuỗi thành các giá trị nguyên, sử dụng dấu "|" làm điểm phân cách
            String[] values = dataFromServer.split("\\|");
            System.out.println(values);
            
            // Tính tổng các giá trị nguyên
            int sum = 0;
            for (String value : values) {
                sum += Integer.parseInt(value);

            }
            System.out.println("Sum: " + sum);

            // Gửi tổng lên máy chủ
            out.println(sum);

            // Đóng kết nối
            socket.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
