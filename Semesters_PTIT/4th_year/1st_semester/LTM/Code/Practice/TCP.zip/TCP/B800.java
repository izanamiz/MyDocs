/*
Một chương trình (tạm gọi là server) được triển khai tại địa chỉ 10.21.96.15 (hỗ trợ thời gian giao tiếp tối đa cho mỗi yêu cầu là 5s), yêu cầu xây dựng chương trình (tạm gọi là client) thực hiện kết nối tới server tại cổng 807, sử dụng luồng byte dữ liệu (DataInputStream/DataOutputStream) để trao đổi thông tin theo thứ tự: 
a.	Gửi chuỗi là mã sinh viên và mã câu hỏi theo định dạng "studentCode;qCode". Ví dụ: "B15DCCN999;800"
b.	Nhận lần lượt hai số nguyên a và b từ server
c.	Thực hiện tính toán tổng, tích và gửi lần lượt từng giá trị theo đúng thứ tự trên lên server
d.	Đóng kết nối và kết thúc
*/ 
import java.io.*;
import java.net.Socket;

public class Bai1 {

    public static void main(String[] args) throws IOException {
        String address = "10.21.135.64";
        int port = 807;

        Socket socket = new Socket(address, port);
        DataInputStream dis = new DataInputStream(socket.getInputStream());
        DataOutputStream dos = new DataOutputStream(socket.getOutputStream());

        String value = "B20DCCN535;800";
        dos.writeUTF(value);
        int a = dis.readInt();
        int b = dis.readInt();
        System.out.printf("a=%d, b=%d\n", a, b);
        dos.writeInt(a + b);
        dos.writeInt(a * b);
        socket.close();
    }
}