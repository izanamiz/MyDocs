/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bai931;

import static bai931.UDPClient.getResult;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;

/**
 *
 * @author trant
 */
public class UDPServer {
    public static void main(String[] args) throws SocketException, IOException {
        DatagramSocket server = new DatagramSocket(999);
    
        // nhan du lieu tu server
        byte[] buff = new byte[1024];
        DatagramPacket dp1 = new DatagramPacket(buff, buff.length);
        server.receive(dp1);
        String res = new String(dp1.getData()).trim();
        System.out.println(res);
        
        // gui ket qua len server
        String result = "requestId;7,4,5,9,12,16";
        DatagramPacket dp2 = new DatagramPacket(result.getBytes(), result.length(),
                dp1.getAddress(), dp1.getPort());
        server.send(dp2);
    }
}
