/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bai931;

import java.io.IOException;
import java.lang.reflect.Array;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.util.TreeSet;

/**
 *
 * @author trant
 */
public class UDPClient {
    public static String getResult(String str) {
        String result = "requestId;";
        String rg = "[;,\\s]+";
        String[] arr = str.split(rg);
        
        // đoạn khác nhau giữa các bài
        TreeSet<Integer> set = new TreeSet<>();
        for(int i=1;i<arr.length;i++){
            int n = Integer.parseInt(arr[i]);
            set.add(n);
        }
        result+=set.last()+","+set.first();
        return result;
    }

    public static void main(String[] args) throws IOException {
        DatagramSocket client = new DatagramSocket();
        // gui? msv len server
        String msv = ";B20DCCN602;931";
        DatagramPacket dp = new DatagramPacket(msv.getBytes(), msv.length(),
                InetAddress.getByName("10.170.42.202"), 999);
        client.send(dp);
        
        // nhan du lieu tu server
        byte[] buff = new byte[1024];
        DatagramPacket dp1 = new DatagramPacket(buff, buff.length);
        client.receive(dp1);
        String res = new String(dp1.getData()).trim();
        
        // gui ket qua len server
        String result = getResult(res);
        DatagramPacket dp2 = new DatagramPacket(result.getBytes(), result.length(),
                InetAddress.getByName("10.170.42.202"), 999);
        client.send(dp2);
    }
}
