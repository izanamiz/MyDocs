
package ws_baithi;

public class WS_BAITHI {
    public static void main(String[] args) {
        // TODO code application logic here
        ws.Num_Service service = new ws.Num_Service();
        ws.Num port = service.getNumPort();
        String str = port.getNumber("");
        System.out.println(str);

        String id = str.trim().split(";")[0];
        String string = str.trim().split(";")[1];
        System.out.println(id);
        System.out.println(string);

        String[] s = string.trim().split(",");
        for (int i = 0; i < s.length; i++) {
            for (int j = 0; j < s.length - 1; j++) {
                String so1 = s[j].trim() + s[j + 1].trim();
                String so2 = s[j + 1].trim() + s[j].trim();
                if (Long.parseLong(so1) < Long.parseLong(so2)) {
                    String sodoi = s[j];
                    s[j] = s[j + 1];
                    s[j + 1] = sodoi;
                }
            }
        }
        String kq = "";
        for (int i = 0; i < s.length; i++) {
            kq += s[i].trim();
        }
        System.out.println(kq);

        port.greatestNumber(Integer.parseInt(id), kq);

    }


}
