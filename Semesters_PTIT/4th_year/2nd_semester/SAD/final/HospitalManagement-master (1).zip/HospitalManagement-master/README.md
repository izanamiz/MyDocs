Django Project cmd


django-admin startproject xxx
py manage.py startapp xxx

python manage.py makemigrations
python manage.py migrate

python manage.py runserver 800x  

check vụ đơn thuốc bên medicine_record
thêm model nằm viện vào module patient

patient - 8000: oke
staff - 8001: oke 
appointment - 8002: oke
room - 8003: oke
medicine - 8004: oke
medicine_record - 8005: oke
bill - 8006: oke
