from django.apps import AppConfig


class BedInfoConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'bed_info'
