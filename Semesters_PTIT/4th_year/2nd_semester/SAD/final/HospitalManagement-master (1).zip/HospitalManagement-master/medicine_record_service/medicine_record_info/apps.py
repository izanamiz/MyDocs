from django.apps import AppConfig


class MedicineRecordInfoConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'medicine_record_info'
