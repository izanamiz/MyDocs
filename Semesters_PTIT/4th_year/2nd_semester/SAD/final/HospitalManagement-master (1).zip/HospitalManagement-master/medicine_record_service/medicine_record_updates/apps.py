from django.apps import AppConfig


class MedicineRecordUpdatesConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'medicine_record_updates'
