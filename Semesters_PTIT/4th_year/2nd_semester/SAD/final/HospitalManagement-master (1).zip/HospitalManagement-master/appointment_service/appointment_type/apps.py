from django.apps import AppConfig


class AppointmentTypeConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'appointment_type'
