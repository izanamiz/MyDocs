from django.apps import AppConfig


class MedicineInfoConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'medicine_info'
