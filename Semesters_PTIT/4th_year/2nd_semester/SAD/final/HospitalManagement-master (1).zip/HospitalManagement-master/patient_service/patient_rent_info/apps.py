from django.apps import AppConfig


class PatientRentInfoConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'patient_rent_info'
