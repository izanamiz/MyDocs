from django.apps import AppConfig


class PatientStatusConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'patient_status'
