#include <bits/stdc++.h>
using namespace std;
typedef long long ll;

const int e = 4;
const int r = 10;

struct node
{
    string name;
    char data;
    int fre;
    node *left;
    node *right;
    node(){};
    node(string n, char d, int f, node *L, node *R) : name(n), data(d), fre(f), left(L), right(R){};
};

typedef node *Node;

bool isNYTNode(Node alpha)
{
    if (alpha->name == "square" && alpha->data == '\0' && alpha->fre == 0 && alpha->left == NULL && alpha->right == NULL)
        return true;

    return false;
}

string to_binary(int n)
{
    string result = "";
    while (n > 0)
    {
        result = result + char(n % 2 + 48);
        n = n / 2;
    }
    reverse(result.begin(), result.end());
    return result;
}

bool onTree(char c, string &str, Node &root)
{
    bool ok = false;
    Node p = root;
    while (p->name == "oval")
    {
        if ((p->left)->data == c)
        {
            str = str + "0";
            ok = true;
            break;
        }
        else if ((p->right)->data == c)
        {
            str = str + "1";
            ok = true;
            break;
        }
        else if ((p->left)->name == "oval")
        {
            str = str + "0";
            p = p->left;
        }
        else if ((p->right)->name == "oval")
        {
            str = str + "1";
            p = p->right;
        }
        else
        {
            str = str + "0";
            p = p->left;
        }
    }
    return ok;
}

void updateTree(char c, Node &root)
{
    Node p = root;
    while (p->name == "oval")
    {
        (p->fre)++;
        if ((p->left)->data == c)
        {
            ((p->left)->fre)++;
            break;
        }
        else if ((p->right)->data == c)
        {
            ((p->right)->fre)++;
            break;
        }
        else if ((p->left)->name == "oval")
        {
            p = p->left;
        }
        else if ((p->right)->name == "oval")
        {
            p = p->right;
        }
        else
        {
            p = p->left;
        }
    }
}

void balanceTree(Node &root)
{
    Node p = root;
    while (p->name == "oval")
    {
        if ((p->left)->fre > (p->right)->fre)
        {
            swap(p->left, p->right);
        }
        if ((p->left)->name == "oval")
        {
            p = p->left;
        }
        else if ((p->right)->name == "oval")
        {
            p = p->right;
        }
        else
        {
            p = p->left;
        }
    }
}

void Adaptive_Huffman_Encoding()
{
    string s;
    cin >> s;
    string NYTCode, FixedCode;
    Node root = new node("square", '\0', 0, NULL, NULL);
    for (char c : s)
    {
        int k = int(c - 96);
        // biểu diễn nhị phân (e + 1) bit của k-1
        if (k <= 2 * r)
        {
            FixedCode = to_binary(k - 1);
            while (FixedCode.size() < e + 1)
                FixedCode = '0' + FixedCode;
        }
        // biểu diễn nhị phân e bit của (k-r-1)
        else
        {
            FixedCode = to_binary(k - r - 1);
            while (FixedCode.size() < e)
                FixedCode = '0' + FixedCode;
        }
        // Kiểm tra kí tự đang xét có trên cây hay không đồng thời tìm NYTCode
        string str = "";
        bool check = onTree(c, str, root);
        if (check)
        {
            NYTCode = str;
            FixedCode = "";
            updateTree(c, root);
        }
        else
        {
            NYTCode = str;
            // Tìm NYTNode đồng thời tăng fre ở các node oval
            Node p = root;
            while (!isNYTNode(p))
            {
                (p->fre)++;
                if ((p->left)->data == '\0')
                {
                    p = p->left;
                }
                else
                {
                    p = p->right;
                }
            }
            Node R = new node("square", c, 1, NULL, NULL);
            Node NYTNode = new node("square", '\0', 0, NULL, NULL);
            p->name = "oval";
            p->data = '\0';
            p->fre = 1;
            p->left = NYTNode;
            p->right = R;
            if (isNYTNode(root))
                NYTCode = "";
        }
        balanceTree(root);
        cout << c << ": " << NYTCode + FixedCode << endl;
    }
}

int main()
{
    cout << "Adaptive Huffman Encoding:" << endl;
    Adaptive_Huffman_Encoding();
}