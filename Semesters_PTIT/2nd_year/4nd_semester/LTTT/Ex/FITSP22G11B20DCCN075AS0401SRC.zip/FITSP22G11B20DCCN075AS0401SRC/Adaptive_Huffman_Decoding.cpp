#include <bits/stdc++.h>
using namespace std;
typedef long long ll;

const int e = 4;
const int r = 10;

struct node
{
    string name;
    char data;
    int fre;
    node *left;
    node *right;
    node(){};
    node(string n, char d, int f, node *L, node *R) : name(n), data(d), fre(f), left(L), right(R){};
};

typedef node *Node;

bool isNYTNode(Node alpha)
{
    if (alpha->name == "square" && alpha->data == '\0' && alpha->fre == 0 && alpha->left == NULL && alpha->right == NULL)
        return true;

    return false;
}

void updateTree(char c, Node &root)
{
    Node p = root;
    while (p->name == "oval")
    {
        if ((p->left)->data == c)
        {
            ((p->left)->fre)++;
            break;
        }
        else if ((p->right)->data == c)
        {
            ((p->right)->fre)++;
            break;
        }
        else if ((p->left)->name == "oval")
        {
            p = p->left;
        }
        else if ((p->right)->name == "oval")
        {
            p = p->right;
        }
        else
        {
            p = p->left;
        }
    }
}

void balanceTree(Node &root)
{
    Node p = root;
    while (p->name == "oval")
    {
        if ((p->left)->fre > (p->right)->fre)
        {
            swap(p->left, p->right);
        }
        if ((p->left)->name == "oval")
        {
            p = p->left;
        }
        else if ((p->right)->name == "oval")
        {
            p = p->right;
        }
        else
        {
            p = p->left;
        }
    }
}

void Adaptive_Huffman_Decoding()
{
    string s;
    cin >> s;
    Node root = new node("square", '\0', 0, NULL, NULL);
    int i = 0;
    while (i < s.size())
    {
        // Nếu cây rỗng
        if (isNYTNode(root))
        {
            // Đọc e bit tiếp theo
            int k = 0, j;
            string tmp = "";
            for (j = i; j < i + e; j++)
            {
                k = k * 2 + int(s[j] - 48);
                tmp = tmp + s[j];
            }
            // Nếu k <= r chuyển e+1 bit thành số thập phân và cộng thêm 1
            if (k <= r)
            {
                k = k * 2 + int(s[j] - 48) + 1;
                tmp = tmp + s[j];
                i = j + 1;
            }
            else
            {
                k = k + r + 1;
                i = j;
            }
            cout << tmp << ": " << char(k + 96) << endl;
            // thêm kí tự vừa giải mã vào cây
            Node NYTNode = new node("square", '\0', 0, NULL, NULL);
            Node R = new node("square", char(k + 96), 1, NULL, NULL);
            root = new node("oval", '\0', 1, NYTNode, R);
        }
        else
        {
            string code = "";
            Node p = root;
            while (p->name == "oval")
            {
                (p->fre)++;
                code = code + s[i];
                if (s[i] == '0')
                    p = p->left;
                else
                    p = p->right;
                i++;
            }
            // Nếu node lá là NYTNode thì đọc e bit tiếp theo và mở rộng cây
            if (p->data == '\0')
            {
                int k = 0, j;
                string tmp = "";
                for (j = i; j < i + e; j++)
                {
                    k = k * 2 + int(s[j] - 48);
                    tmp = tmp + s[j];
                }
                // Nếu k <= r chuyển e+1 bit thành số thập phân và cộng thêm 1
                if (k <= r)
                {
                    k = k * 2 + int(s[j] - 48) + 1;
                    tmp = tmp + s[j];
                    i = j + 1;
                }
                else
                {
                    k = k + r + 1;
                    i = j;
                }
                Node NYTNode = new node("square", '\0', 0, NULL, NULL);
                Node R = new node("square", char(k + 96), 1, NULL, NULL);
                p->name = "oval";
                p->data = '\0';
                p->fre = 1;
                p->left = NYTNode;
                p->right = R;
                cout << code << ": "
                     << "NYT" << endl;
                cout << tmp << ": " << char(k + 96) << endl;
            }
            else
            {
                cout << code << ": " << p->data << endl;
                updateTree(p->data, root);
            }
            balanceTree(root);
        }
    }
}

int main()
{
    cout << "Adaptive Huffman Decoding:" << endl;
    Adaptive_Huffman_Decoding();
}