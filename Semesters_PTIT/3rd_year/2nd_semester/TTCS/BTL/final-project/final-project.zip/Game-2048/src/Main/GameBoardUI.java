package Main;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;

import javax.swing.JComponent;

public class GameBoardUI extends JComponent{
	private static final long serialVersionUID = 5872942232468416972L;

	TileUI[][] tiles=new TileUI[4][4];
	
	GameBoard board;
	
	public GameBoardUI(GameBoard b)
	{
		board=b;
		
		for(int x=0;x<4;x++)
		{
			for(int y=0;y<4;y++)
			{
				tiles[y][x]=new TileUI(new Tile(0));
				tiles[y][x].tilePos(x, y);
				add(tiles[y][x]);
			}
		}
		
	}
	
	public Dimension getPreferredSize(){
		return new Dimension(400, 400);
	}
	
	public void paintComponent(Graphics g){
		for(int x=0;x<4;x++){
			for(int y=0;y<4;y++){
				tiles[y][x].tile.pow=board.getTile(x, y);
			}
		}
		g.setColor(new Color(0xbbada0));
		g.fillRect(0, 0, 400, 400);
	}
}
