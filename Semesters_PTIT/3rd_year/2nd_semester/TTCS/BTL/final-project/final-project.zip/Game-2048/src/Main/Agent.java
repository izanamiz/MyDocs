package Main;

public interface Agent {
	int makeMove(GameBoard b);
}
