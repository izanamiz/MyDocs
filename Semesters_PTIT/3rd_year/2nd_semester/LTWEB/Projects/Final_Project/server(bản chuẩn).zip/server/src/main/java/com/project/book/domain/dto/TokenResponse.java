package com.project.book.domain.dto;

import lombok.Data;

@Data
public class TokenResponse {
    private String token;
}
